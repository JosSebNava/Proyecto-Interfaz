package Caducados;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

public class GestionProductos extends JFrame {

    private static final String URL = "jdbc:mysql://localhost:3306/proyecto";
    private static final String USUARIO = "root";
    private static final String CONTRASENA = "";

    private JTable tablaProductos;
    private JTable tablaCaducados;
    private DefaultTableModel modeloProductos;
    private DefaultTableModel modeloCaducados;

    public GestionProductos() {
        super("Gestión de Productos");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(600, 400);

        // Configuración de las tablas
        modeloProductos = new DefaultTableModel();
        modeloProductos.addColumn("ID");
        modeloProductos.addColumn("Nombre");
        modeloProductos.addColumn("Fecha Caducidad");

        modeloCaducados = new DefaultTableModel();
        modeloCaducados.addColumn("ID");
        modeloCaducados.addColumn("Nombre");
        modeloCaducados.addColumn("Fecha Caducidad");

        tablaProductos = new JTable(modeloProductos);
        tablaCaducados = new JTable(modeloCaducados);

        // Botón para simular el paso del tiempo y detectar productos caducados
        JButton btnActualizarCaducados = new JButton("Actualizar Caducados");
        btnActualizarCaducados.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                detectarProductosCaducados();
            }
        });

        // Configuración del diseño de la interfaz
        setLayout(new BorderLayout());
        JPanel panelBotones = new JPanel();
        panelBotones.add(btnActualizarCaducados);
        add(panelBotones, BorderLayout.NORTH);

        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, new JScrollPane(tablaProductos), new JScrollPane(tablaCaducados));
        add(splitPane, BorderLayout.CENTER);

        // Configuración de la conexión a la base de datos
        try {
            Connection conexion = DriverManager.getConnection(URL, USUARIO, CONTRASENA);

            // Obtener productos desde la base de datos y llenar la tabla
            List<Producto> productos = obtenerProductosDesdeBD(conexion);
            llenarTablaProductos(productos);

            conexion.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    private void llenarTablaProductos(List<Producto> productos) {
        // Limpiar la tabla antes de agregar nuevos datos
        modeloProductos.setRowCount(0);

        // Agregar los productos a la tabla
        for (Producto producto : productos) {
            Object[] fila = {producto.getId(), producto.getNombre(), producto.getFechaCaducidad()};
            modeloProductos.addRow(fila);
        }
    }

    private void llenarTablaCaducados(List<Producto> caducados) {
        // Limpiar la tabla antes de agregar nuevos datos
        modeloCaducados.setRowCount(0);

        // Agregar los productos caducados a la tabla
        for (Producto caducado : caducados) {
            Object[] fila = {caducado.getId(), caducado.getNombre(), caducado.getFechaCaducidad()};
            modeloCaducados.addRow(fila);
        }
    }

    private void detectarProductosCaducados() {
        // Obtener la fecha actual
        Date fechaActual = new Date();

        // Obtener los productos desde la base de datos
        List<Producto> productos = obtenerProductosDesdeBD(null);

        // Filtrar los productos caducados
        List<Producto> caducados = new LinkedList<>();
        for (Producto producto : productos) {
            if (producto.getFechaCaducidad().before(fechaActual)) {
                // Agregar el producto a la lista de caducados
                caducados.add(producto);

                // Mover el producto caducado a la tabla de caducados en la base de datos
                moverACaducados(producto.getId());
            }
        }

        // Mostrar los productos caducados en la tabla correspondiente
        llenarTablaCaducados(caducados);
    }

    private void moverACaducados(int productoId) {
        try {
            Connection conexion = DriverManager.getConnection(URL, USUARIO, CONTRASENA);

            // Obtener el producto de la tabla de productos
            String obtenerProductoSQL = "SELECT * FROM productos WHERE id = ?";
            try (PreparedStatement obtenerProductoStmt = conexion.prepareStatement(obtenerProductoSQL)) {
                obtenerProductoStmt.setInt(1, productoId);
                ResultSet resultSet = obtenerProductoStmt.executeQuery();

                if (resultSet.next()) {
                    // Insertar el producto en la tabla de caducados
                    String insertarCaducadoSQL = "INSERT INTO caducados (id, nombre, fecha_caducidad) VALUES (?, ?, ?)";
                    try (PreparedStatement insertarCaducadoStmt = conexion.prepareStatement(insertarCaducadoSQL)) {
                        insertarCaducadoStmt.setInt(1, resultSet.getInt("id"));
                        insertarCaducadoStmt.setString(2, resultSet.getString("nombre"));
                        insertarCaducadoStmt.setDate(3, resultSet.getDate("fecha_caducidad"));
                        insertarCaducadoStmt.executeUpdate();
                    }

                    // Eliminar el producto de la tabla de productos
                    String eliminarProductoSQL = "DELETE FROM productos WHERE id = ?";
                    try (PreparedStatement eliminarProductoStmt = conexion.prepareStatement(eliminarProductoSQL)) {
                        eliminarProductoStmt.setInt(1, productoId);
                        eliminarProductoStmt.executeUpdate();
                    }
                }

                resultSet.close();
            }

            conexion.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    private List<Producto> obtenerProductosDesdeBD(Connection connection) {
        List<Producto> productos = new LinkedList<>();

        try {
            Connection conexion = DriverManager.getConnection(URL, USUARIO, CONTRASENA);
            Statement statement = conexion.createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT * FROM productos");

            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String nombre = resultSet.getString("nombre");
                Date fechaCaducidad = resultSet.getDate("fecha_caducidad");

                Producto producto = new Producto(id, nombre, fechaCaducidad);
                productos.add(producto);
            }

            resultSet.close();
            statement.close();
            conexion.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        return productos;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new GestionProductos().setVisible(true));
    }
}

class Producto {
    private int id;
    private String nombre;
    private Date fechaCaducidad;

    public Producto(int id, String nombre, Date fechaCaducidad) {
        this.id = id;
        this.nombre = nombre;
        this.fechaCaducidad = fechaCaducidad;
    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public Date getFechaCaducidad() {
        return fechaCaducidad;
    }
}

